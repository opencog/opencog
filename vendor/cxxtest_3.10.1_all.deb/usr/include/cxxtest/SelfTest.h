#ifndef __cxxtest_SelfTest_h__
#define __cxxtest_SelfTest_h__

#define CXXTEST_SUITE(name)
#define CXXTEST_CODE(member)

#endif // __cxxtest_SelfTest_h__
